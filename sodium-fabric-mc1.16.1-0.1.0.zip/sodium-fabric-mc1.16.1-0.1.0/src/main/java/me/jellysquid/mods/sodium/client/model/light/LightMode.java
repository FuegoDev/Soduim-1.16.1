package me.jellysquid.mods.sodium.client.model.light;

public enum LightMode {
    SMOOTH,
    FLAT
}

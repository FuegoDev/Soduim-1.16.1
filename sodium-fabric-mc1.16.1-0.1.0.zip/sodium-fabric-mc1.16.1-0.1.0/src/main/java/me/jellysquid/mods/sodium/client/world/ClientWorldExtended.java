package me.jellysquid.mods.sodium.client.world;

public interface ClientWorldExtended {
    long getBiomeSeed();
}

package me.jellysquid.mods.sodium.client.gui.options;

public interface TextProvider {
    String getLocalizedName();
}
